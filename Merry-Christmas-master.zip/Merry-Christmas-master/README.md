#圣诞节电子贺卡——用代码来泡妹子

用空闲时间设计了一张圣诞节的电子贺卡，用CSS3实现动画效果

使用github的pages或者coding的项目演示来部署代码，将项目地址生成一个二维码

###使用场景

*直接把二维码直接发给妹子

*把二维码打印在送给妹子的礼物包装盒上

*发挥你的创造力通过各种途径让妹子看到它

这是我为给妹子部署的：

<img src="qrcode.png" width="200">

设计稿PSD下载地址：<a href="http://pan.baidu.com/s/1gdw3lEr" target="_blank">[下载]</a>